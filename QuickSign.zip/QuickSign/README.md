# QuickSign
A chrome extension to let you quickly sign up for websites using a temporary account

PLEASE NOTE: This extension uses plaintext password storage. Please do NOT use this as a password manager or use the accounts created through this extension for anything other than a temporary period as this is incredibly insecure. This extension is made to facilitate the creation of temporary accounts for access to websites that require a login without forfeiting your personal email/password information, and NOT to ease in the creation of permanent or long-term website accounts. 

The creator of this extension is NOT responsible for any damages caused by penetration into the local storage of the extension used for malicious purposes.

It is forbidden to use this extension for any illegal purpose or with the intention to facilitate illegal action.

# Resources used
Mail.TM API: https://docs.mail.tm/
Cemalgnlts' API Wrapper: https://github.com/cemalgnlts/Mailjs